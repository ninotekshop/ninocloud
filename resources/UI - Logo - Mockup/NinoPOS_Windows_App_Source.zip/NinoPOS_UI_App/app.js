// Mock Database
const products = [
  { id: 'SP01', name: 'Lẩu Thái Hải Sản (Nồi lớn)', category: 'launuong', price: 280000, img: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=300' },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', category: 'launuong', price: 180000, img: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=300' },
  { id: 'SP03', name: 'Cánh Gà Chiên Nước Mắm', category: 'khaivi', price: 95000, img: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=300' },
  { id: 'SP04', name: 'Mực Trứng Nướng Muối Ớt', category: 'launuong', price: 160000, img: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=300' },
  { id: 'SP05', name: 'Bò Tơ Cuộn Nấm Kim Châm', category: 'monchinh', price: 150000, img: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=300' },
  { id: 'SP06', name: 'Bia Tiger Nâu (Két 24 lon)', category: 'biaruo', price: 420000, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=300' },
  { id: 'SP07', name: 'Bia Heineken Bạc (Két 24 lon)', category: 'biaruo', price: 480000, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=300' },
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', category: 'biaruo', price: 380000, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=300' },
  { id: 'SP09', name: 'Bia Tiger (Lon lẻ)', category: 'biaruo', price: 20000, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=300' },
  { id: 'SP10', name: 'Trà Đào Cam Sả', category: 'giaikhat', price: 35000, img: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=300' },
  { id: 'SP11', name: 'Cafe Muối Quy Nhơn', category: 'giaikhat', price: 28000, img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=300' },
  { id: 'SP12', name: 'Đậu Phộng Rang Tỏi Ớt', category: 'anvat', price: 25000, img: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=300' }
];

const tables = [
  { id: 'T01', name: 'Bàn T-01', area: 'Sân Vườn', status: 'empty', total: 0 },
  { id: 'T02', name: 'Bàn T-02', area: 'Sân Vườn', status: 'occupied', total: 680000, time: '18:20' },
  { id: 'T03', name: 'Bàn T-03', area: 'Sân Vườn', status: 'empty', total: 0 },
  { id: 'T04', name: 'Bàn T-04', area: 'Sân Vườn', status: 'occupied', total: 1420000, time: '17:45' },
  { id: 'T05', name: 'Bàn T-05', area: 'Sân Vườn', status: 'empty', total: 0 },
  { id: 'T12', name: 'Bàn T-12', area: 'Sân Vườn', status: 'occupied', total: 1250000, time: '19:10' },
  { id: 'L01', name: 'Lầu 1 - B01', area: 'Tầng 2', status: 'empty', total: 0 },
  { id: 'L02', name: 'Lầu 1 - B02', area: 'Tầng 2', status: 'waiting', total: 950000, time: '19:00' },
  { id: 'VIP1', name: 'VIP 1 - Biển Quy Nhơn', area: 'VIP', status: 'occupied', total: 3850000, time: '18:00' },
  { id: 'VIP2', name: 'VIP 2 - Ghềnh Ráng', area: 'VIP', status: 'empty', total: 0 }
];

// Current Active Order State
let currentOrder = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', price: 380000, qty: 1 },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', price: 180000, qty: 1 },
  { id: 'SP03', name: 'Cánh Gà Chiên Nước Mắm', price: 95000, qty: 2 },
  { id: 'SP09', name: 'Bia Tiger (Lon lẻ)', price: 20000, qty: 6 }
];

let selectedCategory = 'all';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  initClock();
  renderProducts();
  renderOrderTable();
  renderFloorGrid();
  renderInventoryTable();
  setupNavigation();
  setupShortcuts();
  setupSearch();
  setupPaymentMethods();
});

// Real-time Clock
function initClock() {
  const update = () => {
    const d = new Date();
    document.getElementById('clock').innerText = d.toLocaleTimeString('vi-VN');
  };
  setInterval(update, 1000);
  update();
}

// Navigation Tabs
function setupNavigation() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.app-view').forEach(v => v.classList.remove('active-view'));

      btn.classList.add('active');
      const targetView = btn.getAttribute('data-view');
      document.getElementById(targetView).classList.add('active-view');
    });
  });

  // Category buttons
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedCategory = btn.getAttribute('data-cat');
      renderProducts();
    });
  });
}

// Render Products Grid
function renderProducts(filterText = '') {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';

  const filtered = products.filter(p => {
    const matchCat = (selectedCategory === 'all' || p.category === selectedCategory);
    const matchSearch = p.name.toLowerCase().includes(filterText.toLowerCase()) || p.id.toLowerCase().includes(filterText.toLowerCase());
    return matchCat && matchSearch;
  });

  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => addToOrder(p);
    card.innerHTML = `
      <div class="product-img-wrap">
        <img src="${p.img}" alt="${p.name}" loading="lazy">
      </div>
      <div class="product-title">${p.name}</div>
      <div class="product-price">${p.price.toLocaleString('vi-VN')} đ</div>
      <span class="product-badge">${p.id}</span>
    `;
    grid.appendChild(card);
  });
}

// Add Item To Order
function addToOrder(item) {
  const exist = currentOrder.find(o => o.id === item.id);
  if (exist) {
    exist.qty += 1;
  } else {
    currentOrder.push({ ...item, qty: 1 });
  }
  renderOrderTable();
  showToast(`Đã thêm: ${item.name}`);
}

// Render Order Table
function renderOrderTable() {
  const tbody = document.getElementById('orderTableBody');
  tbody.innerHTML = '';
  let subtotal = 0;

  currentOrder.forEach((item, index) => {
    const itemTotal = item.price * item.qty;
    subtotal += itemTotal;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${item.name}</strong></td>
      <td>
        <div class="qty-control">
          <button class="qty-btn" onclick="updateQty(${index}, -1)">-</button>
          <span>${item.qty}</span>
          <button class="qty-btn" onclick="updateQty(${index}, 1)">+</button>
        </div>
      </td>
      <td>${item.price.toLocaleString('vi-VN')}</td>
      <td><strong>${itemTotal.toLocaleString('vi-VN')}</strong></td>
      <td><button class="delete-item-btn" onclick="removeItem(${index})"><i class="fa-solid fa-xmark"></i></button></td>
    `;
    tbody.appendChild(tr);
  });

  const vat = Math.round(subtotal * 0.08);
  const grandTotal = subtotal + vat;

  document.getElementById('subTotal').innerText = subtotal.toLocaleString('vi-VN') + ' đ';
  document.getElementById('vatVal').innerText = vat.toLocaleString('vi-VN') + ' đ';
  document.getElementById('grandTotal').innerText = grandTotal.toLocaleString('vi-VN') + ' đ';
}

function updateQty(idx, delta) {
  currentOrder[idx].qty += delta;
  if (currentOrder[idx].qty <= 0) {
    currentOrder.splice(idx, 1);
  }
  renderOrderTable();
}

function removeItem(idx) {
  currentOrder.splice(idx, 1);
  renderOrderTable();
}

// Sơ Đồ Bàn (Floor Map)
function renderFloorGrid() {
  const grid = document.getElementById('floorGrid');
  grid.innerHTML = '';

  tables.forEach(t => {
    const card = document.createElement('div');
    card.className = `table-card ${t.status}`;
    card.onclick = () => selectTable(t);

    let statusText = 'Trống';
    if (t.status === 'occupied') statusText = 'Đang phục vụ';
    if (t.status === 'waiting') statusText = 'Chờ thanh toán';

    card.innerHTML = `
      <div>
        <div class="tbl-name">
          <span>${t.name}</span>
          <span class="tbl-status-badge">${statusText}</span>
        </div>
        <div class="tbl-time">${t.area} ${t.time ? '• ' + t.time : ''}</div>
      </div>
      <div class="tbl-total">${t.total > 0 ? t.total.toLocaleString('vi-VN') + ' đ' : '---'}</div>
    `;
    grid.appendChild(card);
  });
}

function selectTable(t) {
  document.getElementById('currentTableDisplay').innerText = `${t.name} (${t.area})`;
  // Switch to POS view
  document.querySelector('[data-view="pos-view"]').click();
  showToast(`Đã chuyển sang: ${t.name}`);
}

// Bảng Quản lý kho
function renderInventoryTable() {
  const tbody = document.getElementById('inventoryTableBody');
  tbody.innerHTML = '';
  products.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${p.id}</strong></td>
      <td>${p.name}</td>
      <td>${p.category}</td>
      <td>Đơn vị</td>
      <td>${(p.price * 0.65).toLocaleString('vi-VN')} đ</td>
      <td><strong>${p.price.toLocaleString('vi-VN')} đ</strong></td>
      <td><span class="badge ${p.price ? 'success' : ''}">Còn hàng</span></td>
      <td>
        <button class="btn btn-outline btn-sm" onclick="showToast('Chỉnh sửa: ${p.id}')"><i class="fa-solid fa-pen"></i></button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Thanh Toán Modal
function openPaymentModal() {
  const grandTotal = document.getElementById('grandTotal').innerText;
  document.getElementById('payAmountDisplay').innerText = grandTotal;
  document.getElementById('paymentModal').style.display = 'flex';
}

function closePaymentModal() {
  document.getElementById('paymentModal').style.display = 'none';
}

function setupPaymentMethods() {
  document.querySelectorAll('.pay-method-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.pay-method-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.method-subview').forEach(v => v.classList.remove('active'));

      btn.classList.add('active');
      const method = btn.getAttribute('data-method');
      document.getElementById(`method-${method}`).classList.add('active');
    });
  });
}

function completePayment() {
  showToast('✓ Thanh toán thành công! Lệnh in hóa đơn K80 đã gửi.');
  closePaymentModal();
  currentOrder = [];
  renderOrderTable();
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.innerText = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2400);
}

// Windows Physical Hotkeys Support
function setupShortcuts() {
  window.addEventListener('keydown', (e) => {
    if (e.key === 'F1') {
      e.preventDefault();
      document.getElementById('searchInput').focus();
    } else if (e.key === 'F9') {
      e.preventDefault();
      openPaymentModal();
    } else if (e.key === 'F8') {
      e.preventDefault();
      printDraftBill();
    } else if (e.key === 'Escape') {
      closePaymentModal();
    }
  });
}

function setupSearch() {
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', (e) => {
    renderProducts(e.target.value);
  });
}

function printDraftBill() {
  showToast('Đang in phiếu tạm tính cho khách (F8)...');
}

function sendToKitchen() {
  showToast('Đã gửi thông báo chế biến đến Bếp & Quầy Pha Chế!');
}

function openCashDrawer() {
  showToast('Đã kích hoạt mở ngăn kéo đựng tiền (Cash Drawer RJ11)');
}
