# BỘ GIAO DIỆN NINOPOS LICENSE ADMIN STUDIO

Bao gồm 2 phương án tích hợp:
1. license_admin.html: Dùng cho app nền Electron / Web admin. Có sẵn logic copy key 1 chạm và mô phỏng sinh mã key tự động.
2. LicenseAdminWindow.xaml: Dùng trực tiếp cho dự án WinForms / WPF (.NET C#).
