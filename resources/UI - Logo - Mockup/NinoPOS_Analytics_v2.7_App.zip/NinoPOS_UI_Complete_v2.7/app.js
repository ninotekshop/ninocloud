// Mock Database
let products = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', category: 'biaruo', unit: 'Thùng', cost: 290000, price: 380000, stock: 15, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP07', name: 'Bia Heineken Bạc (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 370000, price: 480000, stock: 15, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP09', name: 'Bia Tiger (Lon lẻ)', category: 'biaruo', unit: 'Lon', cost: 12000, price: 20000, stock: 100, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', category: 'launuong', unit: 'Nồi', cost: 110000, price: 180000, stock: 8, img: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=200' }
];

document.addEventListener('DOMContentLoaded', () => {
  initClock();
  setupNavigation();
  renderProducts();
});

function initClock() {
  const update = () => {
    document.getElementById('clock').innerText = new Date().toLocaleTimeString('vi-VN');
  };
  setInterval(update, 1000);
  update();
}

function setupNavigation() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.app-view').forEach(v => v.classList.remove('active-view'));
      btn.classList.add('active');
      const target = btn.getAttribute('data-view');
      document.getElementById(target).classList.add('active-view');
    });
  });
}

function setReportPeriod(period) {
  document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
  event.target.classList.add('active');
  showToast(`Đã lọc dữ liệu báo cáo: ${event.target.innerText}`);
}

function filterReportTable(keyword) {
  const rows = document.querySelectorAll('#reportLedgerTbody tr');
  rows.forEach(r => {
    const text = r.innerText.toLowerCase();
    r.style.display = text.includes(keyword.toLowerCase()) ? '' : 'none';
  });
}

function renderProducts() {
  const grid = document.getElementById('productGrid');
  if (!grid) return;
  grid.innerHTML = '';
  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => showToast(`Đã thêm ${p.name}`);
    card.innerHTML = `
      <div class="product-img-wrap"><img src="${p.img}" alt="${p.name}"></div>
      <div class="product-title">${p.name}</div>
      <div class="product-price">${p.price.toLocaleString('vi-VN')} đ</div>
    `;
    grid.appendChild(card);
  });
}

function openPaymentModal() {
  document.getElementById('payModalAmount').innerText = '1.250.000 đ';
  document.getElementById('paymentModal').style.display = 'flex';
}
function closePaymentModal() { document.getElementById('paymentModal').style.display = 'none'; }
function completePayment() { showToast('✓ Đã thanh toán thành công!'); closePaymentModal(); }
function printDraftBill() { showToast('Đang in phiếu tạm tính K80...'); }
function openCashDrawer() { showToast('Đã kích xung mở két tiền RJ11'); }

function showToast(msg) {
  const t = document.getElementById('toast');
  t.innerText = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2200);
}
