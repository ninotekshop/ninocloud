// Mock Database
let products = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', category: 'biaruo', unit: 'Thùng', cost: 290000, price: 380000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP07', name: 'Bia Heineken Bạc (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 370000, price: 480000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP09', name: 'Bia Tiger (Lon lẻ)', category: 'biaruo', unit: 'Lon', cost: 12000, price: 20000, stock: 100, minStock: 24, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP06', name: 'Bia Tiger Nâu (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 320000, price: 420000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP05', name: 'Bò Tơ Cuộn Nấm Kim Châm', category: 'monchinh', unit: 'Đĩa', cost: 90000, price: 150000, stock: 30, minStock: 10, img: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=200' },
  { id: 'SP11', name: 'Cafe Muối Quy Nhơn', category: 'giaikhat', unit: 'Ly', cost: 10000, price: 28000, stock: 80, minStock: 15, img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=200' },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', category: 'launuong', unit: 'Nồi', cost: 110000, price: 180000, stock: 8, minStock: 10, img: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=200' },
  { id: 'SP03', name: 'Cánh Gà Chiên Mắm', category: 'khaivi', unit: 'Đĩa', cost: 55000, price: 95000, stock: 4, minStock: 10, img: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=200' },
  { id: 'SP12', name: 'Đậu Phộng Rang Tỏi Ớt', category: 'khaivi', unit: 'Đĩa', cost: 10000, price: 25000, stock: 0, minStock: 10, img: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=200' }
];

document.addEventListener('DOMContentLoaded', () => {
  initClock();
  setupNavigation();
  renderInventoryModernTable();
  setupInventoryFilters();
});

function initClock() {
  const update = () => {
    document.getElementById('clock').innerText = new Date().toLocaleTimeString('vi-VN');
  };
  setInterval(update, 1000);
  update();
}

function setupNavigation() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.app-view').forEach(v => v.classList.remove('active-view'));
      btn.classList.add('active');
      const target = btn.getAttribute('data-view');
      document.getElementById(target).classList.add('active-view');
    });
  });
}

// Render Modern Inventory
function renderInventoryModernTable(filterCat = 'all', filterStock = 'all', keyword = '') {
  const tbody = document.getElementById('inventoryModernTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  const filtered = products.filter(p => {
    const matchCat = (filterCat === 'all' || p.category === filterCat);
    const matchKeyword = p.name.toLowerCase().includes(keyword.toLowerCase()) || p.id.toLowerCase().includes(keyword.toLowerCase());
    let matchStock = true;
    if (filterStock === 'low') matchStock = (p.stock > 0 && p.stock <= p.minStock);
    if (filterStock === 'out') matchStock = (p.stock <= 0);
    return matchCat && matchKeyword && matchStock;
  });

  filtered.forEach(p => {
    const isLow = p.stock > 0 && p.stock <= p.minStock;
    const isOut = p.stock <= 0;

    let barColor = '#10b981';
    let statusPill = '<span class="status-pill in-stock">Còn hàng</span>';

    if (isLow) {
      barColor = '#f59e0b';
      statusPill = '<span class="status-pill low-stock">Sắp hết</span>';
    } else if (isOut) {
      barColor = '#ef4444';
      statusPill = '<span class="status-pill out-stock">Hết hàng</span>';
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="text-align:center;">
        <img class="prod-thumb" src="${p.img}" alt="${p.name}">
      </td>
      <td>
        <div class="prod-info-cell">
          <span class="prod-cell-name">${p.name}</span>
          <span class="prod-cell-code">${p.id}</span>
        </div>
      </td>
      <td><span style="font-weight:600; color:#475569;">${getCategoryName(p.category)}</span></td>
      <td>${p.unit}</td>
      <td style="text-align: right; color: #64748b;">${p.cost.toLocaleString('vi-VN')} đ</td>
      <td style="text-align: right; font-weight: 700; color: #0f766e;">${p.price.toLocaleString('vi-VN')} đ</td>
      <td>
        <div class="stock-cell-wrap">
          <div class="stock-val-row">
            <span>${p.stock} ${p.unit}</span>
            <small style="color:#94a3b8">Định mức: ${p.minStock}</small>
          </div>
          <div class="stock-bar-bg">
            <div class="stock-bar-fill" style="width: ${Math.min((p.stock / 50) * 100, 100)}%; background: ${barColor};"></div>
          </div>
        </div>
      </td>
      <td style="text-align: center;">${statusPill}</td>
      <td style="text-align: center;">
        <button class="action-icon-btn" title="Chỉnh sửa" onclick="editProduct('${p.id}')"><i class="fa-solid fa-pen-to-square"></i></button>
        <button class="action-icon-btn delete" title="Xóa món" onclick="deleteProduct('${p.id}')"><i class="fa-solid fa-trash-can"></i></button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function getCategoryName(cat) {
  const map = { biaruo: 'Bia & Rượu', monchinh: 'Món chính', launuong: 'Lẩu & Nướng', khaivi: 'Khai vị', giaikhat: 'Giải khát & Cafe' };
  return map[cat] || cat;
}

function setupInventoryFilters() {
  const searchInput = document.getElementById('invSearchInput');
  const catFilter = document.getElementById('invCategoryFilter');
  const stockFilter = document.getElementById('invStockFilter');

  const applyFilters = () => {
    renderInventoryModernTable(catFilter.value, stockFilter.value, searchInput.value);
  };

  searchInput.addEventListener('input', applyFilters);
  catFilter.addEventListener('change', applyFilters);
  stockFilter.addEventListener('change', applyFilters);
}

// Drawer Handlers
function openProductDrawer(item = null) {
  document.getElementById('productDrawerOverlay').style.display = 'block';
  document.getElementById('productDrawer').classList.add('open');
  if (item) {
    document.getElementById('drawerTitle').innerHTML = `<i class="fa-solid fa-pen-to-square"></i> Sửa: ${item.name}`;
    document.getElementById('drawerProdCode').value = item.id;
    document.getElementById('drawerProdName').value = item.name;
    document.getElementById('drawerProdCat').value = item.category;
    document.getElementById('drawerProdUnit').value = item.unit;
    document.getElementById('drawerProdCost').value = item.cost;
    document.getElementById('drawerProdPrice').value = item.price;
    document.getElementById('drawerProdStock').value = item.stock;
    document.getElementById('drawerProdMinStock').value = item.minStock;
    updateUrlPreview(item.img);
  } else {
    document.getElementById('drawerTitle').innerHTML = `<i class="fa-solid fa-box-open"></i> Thêm Mặt Hàng Mới`;
    document.getElementById('drawerProductForm').reset();
    document.getElementById('imgPreviewBox').innerHTML = '<i class="fa-regular fa-image"></i>';
  }
}

function closeProductDrawer() {
  document.getElementById('productDrawerOverlay').style.display = 'none';
  document.getElementById('productDrawer').classList.remove('open');
}

function handleDrawerSaveProduct(e) {
  e.preventDefault();
  const code = document.getElementById('drawerProdCode').value;
  const name = document.getElementById('drawerProdName').value;
  const price = parseInt(document.getElementById('drawerProdPrice').value);
  const cost = parseInt(document.getElementById('drawerProdCost').value);
  const unit = document.getElementById('drawerProdUnit').value;
  const cat = document.getElementById('drawerProdCat').value;
  const stock = parseInt(document.getElementById('drawerProdStock').value);
  const minStock = parseInt(document.getElementById('drawerProdMinStock').value);
  const img = document.getElementById('drawerProdImgUrl').value || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200';

  const idx = products.findIndex(p => p.id === code);
  if (idx >= 0) {
    products[idx] = { id: code, name, category: cat, unit, cost, price, stock, minStock, img };
    showToast(`Đã cập nhật: ${name}`);
  } else {
    products.unshift({ id: code, name, category: cat, unit, cost, price, stock, minStock, img });
    showToast(`Đã thêm mới: ${name}`);
  }

  closeProductDrawer();
  renderInventoryModernTable();
}

function editProduct(id) {
  const item = products.find(p => p.id === id);
  if (item) openProductDrawer(item);
}

function deleteProduct(id) {
  if (confirm(`Bạn có chắc chắn muốn xóa món [${id}] khỏi hệ thống?`)) {
    products = products.filter(p => p.id !== id);
    renderInventoryModernTable();
    showToast(`Đã xóa món ${id}`);
  }
}

function updateUrlPreview(url) {
  const box = document.getElementById('imgPreviewBox');
  if (url) {
    box.innerHTML = `<img src="${url}" alt="Preview" onerror="this.src='https://via.placeholder.com/70'">`;
  }
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.innerText = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2200);
}
