// Mock Database
let staffMembers = [
  { id: 'NV01', username: 'admin', fullName: 'Lê Trung Hiếu', role: 'ADMIN', pin: '1234', status: 'ACTIVE' },
  { id: 'NV02', username: 'cashier01', fullName: 'Trần Thị Thu Ngân', role: 'CASHIER', pin: '1111', status: 'ACTIVE' },
  { id: 'NV03', username: 'waiter01', fullName: 'Lê Văn Phục Vụ', role: 'WAITER', pin: '2222', status: 'ACTIVE' },
  { id: 'NV04', username: 'waiter02', fullName: 'Nguyễn Văn Nam', role: 'WAITER', pin: '3333', status: 'ACTIVE' },
  { id: 'NV05', username: 'thu_ngan_ca2', fullName: 'Phạm Hồng Nhung', role: 'CASHIER', pin: '4444', status: 'INACTIVE' }
];

let products = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', category: 'biaruo', unit: 'Thùng', cost: 290000, price: 380000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP07', name: 'Bia Heineken Bạc (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 370000, price: 480000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP09', name: 'Bia Tiger (Lon lẻ)', category: 'biaruo', unit: 'Lon', cost: 12000, price: 20000, stock: 100, minStock: 24, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP06', name: 'Bia Tiger Nâu (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 320000, price: 420000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP05', name: 'Bò Tơ Cuộn Nấm Kim Châm', category: 'monchinh', unit: 'Đĩa', cost: 90000, price: 150000, stock: 30, minStock: 10, img: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=200' },
  { id: 'SP11', name: 'Cafe Muối Quy Nhơn', category: 'giaikhat', unit: 'Ly', cost: 10000, price: 28000, stock: 80, minStock: 15, img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=200' },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', category: 'launuong', unit: 'Nồi', cost: 110000, price: 180000, stock: 8, minStock: 10, img: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=200' },
  { id: 'SP03', name: 'Cánh Gà Chiên Mắm', category: 'khaivi', unit: 'Đĩa', cost: 55000, price: 95000, stock: 4, minStock: 10, img: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=200' }
];

const smartTables = [
  { id: 'T01', name: 'Bàn T-01', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'occupied', guests: '4/6', itemsCount: 6, time: '1h 45m', total: 680000 },
  { id: 'T02', name: 'Bàn T-02', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'empty', guests: '0/4', itemsCount: 0, time: '--', total: 0 },
  { id: 'T03', name: 'Bàn T-03', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'occupied', guests: '5/6', itemsCount: 9, time: '2h 10m', total: 864000 },
  { id: 'T04', name: 'Bàn T-04', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'occupied', guests: '2/4', itemsCount: 4, time: '0h 50m', total: 621000 },
  { id: 'T05', name: 'Bàn T-05', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'waiting', guests: '3/4', itemsCount: 5, time: '1h 20m', total: 410400 },
  { id: 'T06', name: 'Bàn T-06', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'empty', guests: '0/6', itemsCount: 0, time: '--', total: 0 }
];

let currentOrder = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', price: 380000, qty: 1 },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', price: 180000, qty: 1 },
  { id: 'SP03', name: 'Cánh Gà Chiên Mắm', price: 95000, qty: 2 }
];

document.addEventListener('DOMContentLoaded', () => {
  initClock();
  setupNavigation();
  setupSettingsNavigation();
  renderStaffTable();
  setupStaffSearch();
  renderProducts();
  renderOrderTable();
  renderSmartTablesGrid();
  renderInventoryModernTable();
});

function initClock() {
  const update = () => {
    document.getElementById('clock').innerText = new Date().toLocaleTimeString('vi-VN');
  };
  setInterval(update, 1000);
  update();
}

// Main Tab Navigation
function setupNavigation() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.app-view').forEach(v => v.classList.remove('active-view'));
      btn.classList.add('active');
      const target = btn.getAttribute('data-view');
      document.getElementById(target).classList.add('active-view');
    });
  });
}

// Settings Sidebar Sub-navigation
function setupSettingsNavigation() {
  document.querySelectorAll('.set-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.set-nav-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.setting-pane').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const secId = btn.getAttribute('data-section');
      const targetPane = document.getElementById(secId);
      if (targetPane) targetPane.classList.add('active');
    });
  });
}

// 1. STAFF MANAGEMENT LOGIC
function renderStaffTable(keyword = '') {
  const tbody = document.getElementById('staffTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  const filtered = staffMembers.filter(s => {
    return s.fullName.toLowerCase().includes(keyword.toLowerCase()) ||
           s.username.toLowerCase().includes(keyword.toLowerCase()) ||
           s.pin.includes(keyword);
  });

  filtered.forEach(s => {
    let roleTag = '';
    let roleLabel = '';
    if (s.role === 'ADMIN') {
      roleTag = 'role-admin';
      roleLabel = 'Quản trị viên (Admin)';
    } else if (s.role === 'CASHIER') {
      roleTag = 'role-cashier';
      roleLabel = 'Thu ngân (Bán hàng)';
    } else {
      roleTag = 'role-waiter';
      roleLabel = 'Nhân viên phục vụ';
    }

    const isAct = s.status === 'ACTIVE';
    const statusHtml = isAct ? 
      `<span class="status-pill in-stock">Đang hoạt động</span>` : 
      `<span class="status-pill out-stock">Đã khóa</span>`;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <div class="staff-user-cell">
          <div class="staff-avatar-circle">${s.fullName.charAt(0)}</div>
          <div class="staff-name-wrap">
            <span class="staff-full-name">${s.fullName}</span>
            <span class="staff-sub-role">${s.id}</span>
          </div>
        </div>
      </td>
      <td><strong style="color:#0f4c81; font-family: monospace;">@${s.username}</strong></td>
      <td><span class="role-tag ${roleTag}">${roleLabel}</span></td>
      <td style="text-align: center;"><span class="pin-code-badge">${s.pin}</span></td>
      <td style="text-align: center;">${statusHtml}</td>
      <td style="text-align: center;">
        <button class="action-icon-btn" title="Chỉnh sửa" onclick="editStaff('${s.id}')"><i class="fa-solid fa-pen-to-square"></i></button>
        <button class="action-icon-btn delete" title="Khóa/Xóa" onclick="deleteStaff('${s.id}')"><i class="fa-solid fa-trash-can"></i></button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function setupStaffSearch() {
  const search = document.getElementById('staffSearchInput');
  if (search) {
    search.addEventListener('input', (e) => {
      renderStaffTable(e.target.value);
    });
  }
}

function openStaffModal(staff = null) {
  const modal = document.getElementById('staffModal');
  const title = document.getElementById('staffModalTitle');
  const form = document.getElementById('staffForm');
  
  if (staff) {
    title.innerHTML = `<i class="fa-solid fa-pen-to-square"></i> Sửa Nhân Viên: ${staff.fullName}`;
    document.getElementById('staffEditId').value = staff.id;
    document.getElementById('staffUsername').value = staff.username;
    document.getElementById('staffUsername').readOnly = true;
    document.getElementById('staffPin').value = staff.pin;
    document.getElementById('staffFullName').value = staff.fullName;
    document.getElementById('staffRole').value = staff.role;
    document.getElementById('staffStatus').value = staff.status;
  } else {
    title.innerHTML = `<i class="fa-solid fa-user-plus"></i> Thêm Mới Nhân Viên`;
    form.reset();
    document.getElementById('staffEditId').value = '';
    document.getElementById('staffUsername').readOnly = false;
  }
  modal.style.display = 'flex';
}

function closeStaffModal() {
  document.getElementById('staffModal').style.display = 'none';
}

function handleSaveStaff(e) {
  e.preventDefault();
  const id = document.getElementById('staffEditId').value;
  const username = document.getElementById('staffUsername').value.trim();
  const pin = document.getElementById('staffPin').value.trim();
  const fullName = document.getElementById('staffFullName').value.trim();
  const role = document.getElementById('staffRole').value;
  const status = document.getElementById('staffStatus').value;

  if (id) {
    const idx = staffMembers.findIndex(s => s.id === id);
    if (idx >= 0) {
      staffMembers[idx] = { id, username, fullName, role, pin, status };
      showToast(`✓ Đã cập nhật nhân viên: ${fullName}`);
    }
  } else {
    const newId = 'NV0' + (staffMembers.length + 1);
    staffMembers.push({ id: newId, username, fullName, role, pin, status });
    showToast(`✓ Đã thêm mới nhân viên: ${fullName}`);
  }

  closeStaffModal();
  renderStaffTable();
}

function editStaff(id) {
  const staff = staffMembers.find(s => s.id === id);
  if (staff) openStaffModal(staff);
}

function deleteStaff(id) {
  const staff = staffMembers.find(s => s.id === id);
  if (!staff) return;
  if (staff.username === 'admin') {
    showToast('⚠️ Không thể xóa tài khoản Quản trị viên gốc!');
    return;
  }
  if (confirm(`Bạn có chắc chắn muốn xóa nhân viên ${staff.fullName} (${staff.username})?`)) {
    staffMembers = staffMembers.filter(s => s.id !== id);
    renderStaffTable();
    showToast(`✓ Đã xóa tài khoản: ${staff.username}`);
  }
}

// Other Mock Engines
function renderProducts() {
  const grid = document.getElementById('productGrid');
  if (!grid) return;
  grid.innerHTML = '';
  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => showToast(`Đã thêm ${p.name}`);
    card.innerHTML = `
      <div class="product-img-wrap"><img src="${p.img}" alt="${p.name}"></div>
      <div class="product-title">${p.name}</div>
      <div class="product-price">${p.price.toLocaleString('vi-VN')} đ</div>
    `;
    grid.appendChild(card);
  });
}

function renderOrderTable() {
  const tbody = document.getElementById('orderTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';
  let subtotal = 0;
  currentOrder.forEach((item) => {
    const total = item.price * item.qty;
    subtotal += total;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${item.name}</strong></td>
      <td>${item.qty}</td>
      <td>${item.price.toLocaleString('vi-VN')}</td>
      <td><strong>${total.toLocaleString('vi-VN')}</strong></td>
      <td></td>
    `;
    tbody.appendChild(tr);
  });
  const vat = Math.round(subtotal * 0.08);
  const grandTotal = subtotal + vat;
  document.getElementById('subTotal').innerText = subtotal.toLocaleString('vi-VN') + ' đ';
  document.getElementById('vatVal').innerText = vat.toLocaleString('vi-VN') + ' đ';
  document.getElementById('grandTotal').innerText = grandTotal.toLocaleString('vi-VN') + ' đ';
}

function renderSmartTablesGrid() {
  const container = document.getElementById('tablesSmartGrid');
  if (!container) return;
  container.innerHTML = '';
  smartTables.forEach(t => {
    const card = document.createElement('div');
    card.className = `modern-table-card ${t.status === 'occupied' ? 'st-occupied' : 'st-empty'}`;
    card.innerHTML = `
      <div class="tbl-card-top">
        <div class="tbl-title-group">
          <span class="tbl-card-title">${t.name}</span>
          <span class="tbl-card-sub">${t.area}</span>
        </div>
        <span class="tbl-status-pill">${t.status === 'occupied' ? 'Đang ngồi' : 'Trống'}</span>
      </div>
      <div class="tbl-card-mid">
        <span>${t.guests}</span><span>${t.time}</span>
      </div>
      <div class="tbl-card-bottom">
        <span class="tbl-price-tag">${t.total > 0 ? t.total.toLocaleString('vi-VN') + ' đ' : 'Bàn trống'}</span>
      </div>
    `;
    container.appendChild(card);
  });
}

function renderInventoryModernTable() {
  const tbody = document.getElementById('inventoryModernTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';
  products.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="text-align:center;"><img class="prod-thumb" src="${p.img}" alt="${p.name}"></td>
      <td><strong>${p.name}</strong><br><small style="color:#94a3b8">${p.id}</small></td>
      <td>Bia/Món</td><td>${p.unit}</td>
      <td style="text-align:right;">${p.cost.toLocaleString('vi-VN')} đ</td>
      <td style="text-align:right; font-weight:bold; color:#0f766e;">${p.price.toLocaleString('vi-VN')} đ</td>
      <td>${p.stock}</td>
      <td style="text-align:center;"><span class="status-pill in-stock">Còn hàng</span></td>
      <td style="text-align:center;"><button class="action-icon-btn"><i class="fa-solid fa-pen"></i></button></td>
    `;
    tbody.appendChild(tr);
  });
}

function openPaymentModal() {
  document.getElementById('payModalAmount').innerText = document.getElementById('grandTotal').innerText;
  document.getElementById('paymentModal').style.display = 'flex';
}
function closePaymentModal() { document.getElementById('paymentModal').style.display = 'none'; }
function completePayment() { showToast('✓ Thanh toán thành công!'); closePaymentModal(); }
function printDraftBill() { showToast('Đang in phiếu tạm tính...'); }
function sendToKitchen() { showToast('Đã báo bếp!'); }
function openCashDrawer() { showToast('Đã kích xung mở két tiền RJ11'); }

function showToast(msg) {
  const t = document.getElementById('toast');
  t.innerText = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2200);
}
