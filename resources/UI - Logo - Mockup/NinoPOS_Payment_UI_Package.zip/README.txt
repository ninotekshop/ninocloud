# BỘ MÃ NGUỒN POPUP THANH TOÁN NINOPOS

1. checkout.html:
   - Bản tương tác trực tiếp chạy trên nền web / Electron.
   - Hỗ trợ đầy đủ phím tắt: F1 (Tiền mặt), F2 (VietQR), Enter (Hoàn tất in bill).
   - Tích hợp Numpad cảm ứng và tự động tính tiền thối lại theo thời gian thực.

2. CheckoutWindow.xaml:
   - Dùng cho ứng dụng .NET (WPF / C#).
   - Bố cục lưới UniformGrid, DockPanel chuẩn, bo góc và hiệu ứng DropShadow hiện đại.
