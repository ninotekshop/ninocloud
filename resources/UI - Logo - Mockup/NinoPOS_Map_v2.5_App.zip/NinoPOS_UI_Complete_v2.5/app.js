// Mock Database
let products = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', category: 'biaruo', unit: 'Thùng', cost: 290000, price: 380000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP07', name: 'Bia Heineken Bạc (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 370000, price: 480000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP09', name: 'Bia Tiger (Lon lẻ)', category: 'biaruo', unit: 'Lon', cost: 12000, price: 20000, stock: 100, minStock: 24, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP06', name: 'Bia Tiger Nâu (Két 24 lon)', category: 'biaruo', unit: 'Két', cost: 320000, price: 420000, stock: 15, minStock: 10, img: 'https://images.unsplash.com/photo-1608270119339-ff74a4805e26?w=200' },
  { id: 'SP05', name: 'Bò Tơ Cuộn Nấm Kim Châm', category: 'monchinh', unit: 'Đĩa', cost: 90000, price: 150000, stock: 30, minStock: 10, img: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=200' },
  { id: 'SP11', name: 'Cafe Muối Quy Nhơn', category: 'giaikhat', unit: 'Ly', cost: 10000, price: 28000, stock: 80, minStock: 15, img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=200' },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', category: 'launuong', unit: 'Nồi', cost: 110000, price: 180000, stock: 8, minStock: 10, img: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=200' },
  { id: 'SP03', name: 'Cánh Gà Chiên Mắm', category: 'khaivi', unit: 'Đĩa', cost: 55000, price: 95000, stock: 4, minStock: 10, img: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=200' },
  { id: 'SP12', name: 'Đậu Phộng Rang Tỏi Ớt', category: 'khaivi', unit: 'Đĩa', cost: 10000, price: 25000, stock: 0, minStock: 10, img: 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=200' }
];

const smartTables = [
  { id: 'T01', name: 'Bàn T-01', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'occupied', guests: '4/6', itemsCount: 6, time: '1h 45m', total: 680000 },
  { id: 'T02', name: 'Bàn T-02', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'empty', guests: '0/4', itemsCount: 0, time: '--', total: 0 },
  { id: 'T03', name: 'Bàn T-03', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'occupied', guests: '5/6', itemsCount: 9, time: '2h 10m', total: 864000 },
  { id: 'T04', name: 'Bàn T-04', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'occupied', guests: '2/4', itemsCount: 4, time: '0h 50m', total: 621000 },
  { id: 'T05', name: 'Bàn T-05', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'waiting', guests: '3/4', itemsCount: 5, time: '1h 20m', total: 410400 },
  { id: 'T06', name: 'Bàn T-06', area: 'Khu Sân Vườn', areaKey: 'san-vuon', status: 'empty', guests: '0/6', itemsCount: 0, time: '--', total: 0 },
  { id: 'L01', name: 'Tầng 1 - B1', area: 'Tầng 1', areaKey: 'tang-1', status: 'empty', guests: '0/4', itemsCount: 0, time: '--', total: 0 },
  { id: 'L02', name: 'Tầng 1 - B2', area: 'Tầng 1', areaKey: 'tang-1', status: 'reserved', guests: '6/8', itemsCount: 0, time: '19:30', total: 0 },
  { id: 'VIP1', name: 'Phòng VIP 1', area: 'Phòng VIP', areaKey: 'vip', status: 'occupied', guests: '8/10', itemsCount: 14, time: '2h 30m', total: 3450000 },
  { id: 'VIP2', name: 'Phòng VIP 2', area: 'Phòng VIP', areaKey: 'vip', status: 'empty', guests: '0/12', itemsCount: 0, time: '--', total: 0 },
  { id: 'BAR1', name: 'Quầy Bar 1', area: 'Quầy Bar', areaKey: 'bar', status: 'empty', guests: '0/2', itemsCount: 0, time: '--', total: 0 },
  { id: 'BAR2', name: 'Quầy Bar 2', area: 'Quầy Bar', areaKey: 'bar', status: 'occupied', guests: '2/2', itemsCount: 3, time: '0h 30m', total: 240000 }
];

let currentOrder = [
  { id: 'SP08', name: 'Bia 333 (Thùng 24 lon)', price: 380000, qty: 1 },
  { id: 'SP02', name: 'Lẩu Thái Hải Sản (Nồi nhỏ)', price: 180000, qty: 1 },
  { id: 'SP03', name: 'Cánh Gà Chiên Mắm', price: 95000, qty: 2 }
];

let selectedFloorArea = 'all';

document.addEventListener('DOMContentLoaded', () => {
  initClock();
  setupNavigation();
  renderProducts();
  renderOrderTable();
  renderSmartTablesGrid();
  setupFloorTabs();
  renderInventoryModernTable();
  setupInventoryFilters();
});

function initClock() {
  const update = () => {
    document.getElementById('clock').innerText = new Date().toLocaleTimeString('vi-VN');
  };
  setInterval(update, 1000);
  update();
}

function setupNavigation() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.app-view').forEach(v => v.classList.remove('active-view'));
      btn.classList.add('active');
      const target = btn.getAttribute('data-view');
      document.getElementById(target).classList.add('active-view');
    });
  });
}

// 1. SMART FLOOR PLAN ENGINE
function renderSmartTablesGrid() {
  const container = document.getElementById('tablesSmartGrid');
  if (!container) return;
  container.innerHTML = '';

  const filtered = smartTables.filter(t => selectedFloorArea === 'all' || t.areaKey === selectedFloorArea);

  filtered.forEach(t => {
    let statusClass = 'st-empty';
    let statusLabel = 'Trống';
    
    if (t.status === 'occupied') {
      statusClass = 'st-occupied';
      statusLabel = 'Đang ngồi';
    } else if (t.status === 'waiting') {
      statusClass = 'st-waiting';
      statusLabel = 'Chờ Bill';
    } else if (t.status === 'reserved') {
      statusClass = 'st-reserved';
      statusLabel = 'Đặt trước';
    }

    const card = document.createElement('div');
    card.className = `modern-table-card ${statusClass}`;
    card.onclick = () => onSelectTableClick(t);

    card.innerHTML = `
      <div class="tbl-card-top">
        <div class="tbl-title-group">
          <span class="tbl-card-title">${t.name}</span>
          <span class="tbl-card-sub">${t.area}</span>
        </div>
        <span class="tbl-status-pill">${statusLabel}</span>
      </div>

      <div class="tbl-card-mid">
        <span class="tbl-meta-item"><i class="fa-solid fa-user-group"></i> ${t.guests}</span>
        <span class="tbl-meta-item"><i class="fa-solid fa-clock"></i> ${t.time}</span>
        <span class="tbl-meta-item"><i class="fa-solid fa-utensils"></i> ${t.itemsCount} món</span>
      </div>

      <div class="tbl-card-bottom">
        <span class="tbl-price-tag">${t.total > 0 ? t.total.toLocaleString('vi-VN') + ' đ' : 'Bàn trống'}</span>
        <div class="tbl-quick-actions" onclick="event.stopPropagation()">
          <button class="tbl-action-btn" title="In tạm tính (F8)" onclick="quickPrintDraft('${t.name}')"><i class="fa-solid fa-print"></i></button>
          <button class="tbl-action-btn" title="Chuyển/Gộp bàn" onclick="quickTransfer('${t.name}')"><i class="fa-solid fa-arrows-split-up-and-left"></i></button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });
}

function setupFloorTabs() {
  document.querySelectorAll('.floor-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.floor-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      selectedFloorArea = tab.getAttribute('data-area');
      renderSmartTablesGrid();
    });
  });
}

function onSelectTableClick(t) {
  document.getElementById('currentTableDisplay').innerText = `${t.name} (${t.area})`;
  document.querySelector('[data-view="pos-view"]').click();
  showToast(`Đã chọn: ${t.name}`);
}

function quickPrintDraft(name) {
  showToast(`Đang in phiếu tạm tính cho: ${name}`);
}

function quickTransfer(name) {
  showToast(`Mở tính năng chuyển/gộp cho: ${name}`);
}

// 2. INVENTORY DASHBOARD ENGINE
function renderInventoryModernTable(filterCat = 'all', filterStock = 'all', keyword = '') {
  const tbody = document.getElementById('inventoryModernTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  const filtered = products.filter(p => {
    const matchCat = (filterCat === 'all' || p.category === filterCat);
    const matchKeyword = p.name.toLowerCase().includes(keyword.toLowerCase()) || p.id.toLowerCase().includes(keyword.toLowerCase());
    let matchStock = true;
    if (filterStock === 'low') matchStock = (p.stock > 0 && p.stock <= p.minStock);
    if (filterStock === 'out') matchStock = (p.stock <= 0);
    return matchCat && matchKeyword && matchStock;
  });

  filtered.forEach(p => {
    const isLow = p.stock > 0 && p.stock <= p.minStock;
    const isOut = p.stock <= 0;

    let barColor = '#10b981';
    let statusPill = '<span class="status-pill in-stock">Còn hàng</span>';

    if (isLow) {
      barColor = '#f59e0b';
      statusPill = '<span class="status-pill low-stock">Sắp hết</span>';
    } else if (isOut) {
      barColor = '#ef4444';
      statusPill = '<span class="status-pill out-stock">Hết hàng</span>';
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="text-align:center;"><img class="prod-thumb" src="${p.img}" alt="${p.name}"></td>
      <td>
        <div class="prod-info-cell">
          <span class="prod-cell-name">${p.name}</span>
          <span class="prod-cell-code">${p.id}</span>
        </div>
      </td>
      <td><span style="font-weight:600; color:#475569;">${getCategoryName(p.category)}</span></td>
      <td>${p.unit}</td>
      <td style="text-align: right; color: #64748b;">${p.cost.toLocaleString('vi-VN')} đ</td>
      <td style="text-align: right; font-weight: 700; color: #0f766e;">${p.price.toLocaleString('vi-VN')} đ</td>
      <td>
        <div class="stock-cell-wrap">
          <div class="stock-val-row">
            <span>${p.stock} ${p.unit}</span>
            <small style="color:#94a3b8">Định mức: ${p.minStock}</small>
          </div>
          <div class="stock-bar-bg">
            <div class="stock-bar-fill" style="width: ${Math.min((p.stock / 50) * 100, 100)}%; background: ${barColor};"></div>
          </div>
        </div>
      </td>
      <td style="text-align: center;">${statusPill}</td>
      <td style="text-align: center;">
        <button class="action-icon-btn" title="Chỉnh sửa" onclick="editProduct('${p.id}')"><i class="fa-solid fa-pen-to-square"></i></button>
        <button class="action-icon-btn delete" title="Xóa món" onclick="deleteProduct('${p.id}')"><i class="fa-solid fa-trash-can"></i></button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function getCategoryName(cat) {
  const map = { biaruo: 'Bia & Rượu', monchinh: 'Món chính', launuong: 'Lẩu & Nướng', khaivi: 'Khai vị', giaikhat: 'Giải khát & Cafe' };
  return map[cat] || cat;
}

function setupInventoryFilters() {
  const searchInput = document.getElementById('invSearchInput');
  const catFilter = document.getElementById('invCategoryFilter');
  const stockFilter = document.getElementById('invStockFilter');

  const apply = () => {
    renderInventoryModernTable(catFilter.value, stockFilter.value, searchInput.value);
  };

  searchInput.addEventListener('input', apply);
  catFilter.addEventListener('change', apply);
  stockFilter.addEventListener('change', apply);
}

function openProductDrawer(item = null) {
  document.getElementById('productDrawerOverlay').style.display = 'block';
  document.getElementById('productDrawer').classList.add('open');
  if (item) {
    document.getElementById('drawerTitle').innerHTML = `<i class="fa-solid fa-pen-to-square"></i> Sửa: ${item.name}`;
    document.getElementById('drawerProdCode').value = item.id;
    document.getElementById('drawerProdName').value = item.name;
    document.getElementById('drawerProdCat').value = item.category;
    document.getElementById('drawerProdUnit').value = item.unit;
    document.getElementById('drawerProdCost').value = item.cost;
    document.getElementById('drawerProdPrice').value = item.price;
    document.getElementById('drawerProdStock').value = item.stock;
    document.getElementById('drawerProdMinStock').value = item.minStock;
    updateUrlPreview(item.img);
  } else {
    document.getElementById('drawerTitle').innerHTML = `<i class="fa-solid fa-box-open"></i> Thêm Mặt Hàng Mới`;
    document.getElementById('drawerProductForm').reset();
    document.getElementById('imgPreviewBox').innerHTML = '<i class="fa-regular fa-image"></i>';
  }
}

function closeProductDrawer() {
  document.getElementById('productDrawerOverlay').style.display = 'none';
  document.getElementById('productDrawer').classList.remove('open');
}

function handleDrawerSaveProduct(e) {
  e.preventDefault();
  const code = document.getElementById('drawerProdCode').value;
  const name = document.getElementById('drawerProdName').value;
  const price = parseInt(document.getElementById('drawerProdPrice').value);
  const cost = parseInt(document.getElementById('drawerProdCost').value);
  const unit = document.getElementById('drawerProdUnit').value;
  const cat = document.getElementById('drawerProdCat').value;
  const stock = parseInt(document.getElementById('drawerProdStock').value);
  const minStock = parseInt(document.getElementById('drawerProdMinStock').value);
  const img = document.getElementById('drawerProdImgUrl').value || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200';

  const idx = products.findIndex(p => p.id === code);
  if (idx >= 0) {
    products[idx] = { id: code, name, category: cat, unit, cost, price, stock, minStock, img };
    showToast(`Đã cập nhật: ${name}`);
  } else {
    products.unshift({ id: code, name, category: cat, unit, cost, price, stock, minStock, img });
    showToast(`Đã thêm: ${name}`);
  }

  closeProductDrawer();
  renderInventoryModernTable();
}

function editProduct(id) {
  const item = products.find(p => p.id === id);
  if (item) openProductDrawer(item);
}

function deleteProduct(id) {
  if (confirm(`Bạn có chắc muốn xóa món [${id}]?`)) {
    products = products.filter(p => p.id !== id);
    renderInventoryModernTable();
    showToast(`Đã xóa món ${id}`);
  }
}

function updateUrlPreview(url) {
  const box = document.getElementById('imgPreviewBox');
  if (url) box.innerHTML = `<img src="${url}" alt="Preview" onerror="this.src='https://via.placeholder.com/70'">`;
}

// 3. POS ENGINE
function renderProducts() {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => addToOrder(p);
    card.innerHTML = `
      <div class="product-img-wrap"><img src="${p.img}" alt="${p.name}"></div>
      <div class="product-title">${p.name}</div>
      <div class="product-price">${p.price.toLocaleString('vi-VN')} đ</div>
    `;
    grid.appendChild(card);
  });
}

function addToOrder(p) {
  const item = currentOrder.find(o => o.id === p.id);
  if (item) {
    item.qty += 1;
  } else {
    currentOrder.push({ id: p.id, name: p.name, price: p.price, qty: 1 });
  }
  renderOrderTable();
  showToast(`Đã thêm: ${p.name}`);
}

function renderOrderTable() {
  const tbody = document.getElementById('orderTableBody');
  tbody.innerHTML = '';
  let subtotal = 0;

  currentOrder.forEach((item, idx) => {
    const total = item.price * item.qty;
    subtotal += total;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${item.name}</strong></td>
      <td>${item.qty}</td>
      <td>${item.price.toLocaleString('vi-VN')}</td>
      <td><strong>${total.toLocaleString('vi-VN')}</strong></td>
      <td><button style="border:none;background:none;color:#94a3b8;cursor:pointer;" onclick="removeItem(${idx})">&times;</button></td>
    `;
    tbody.appendChild(tr);
  });

  const vat = Math.round(subtotal * 0.08);
  const grandTotal = subtotal + vat;
  document.getElementById('subTotal').innerText = subtotal.toLocaleString('vi-VN') + ' đ';
  document.getElementById('vatVal').innerText = vat.toLocaleString('vi-VN') + ' đ';
  document.getElementById('grandTotal').innerText = grandTotal.toLocaleString('vi-VN') + ' đ';
}

function removeItem(idx) {
  currentOrder.splice(idx, 1);
  renderOrderTable();
}

function openPaymentModal() {
  const grand = document.getElementById('grandTotal').innerText;
  document.getElementById('payModalAmount').innerText = grand;
  document.getElementById('paymentModal').style.display = 'flex';
}

function closePaymentModal() {
  document.getElementById('paymentModal').style.display = 'none';
}

function completePayment() {
  showToast('✓ Thanh toán thành công! Đã gửi lệnh in bill và mở két.');
  closePaymentModal();
  currentOrder = [];
  renderOrderTable();
}

function printDraftBill() {
  showToast('Đang in phiếu tạm tính K80...');
}

function sendToKitchen() {
  showToast('Đã gửi thông báo chế biến đến Bếp!');
}

function openCashDrawer() {
  showToast('Đã mở két tiền RJ11');
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.innerText = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2200);
}
