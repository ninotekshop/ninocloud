let pin = "";

const dots = [...document.querySelectorAll("#pinDots span")];
const currentUser = document.getElementById("currentUser");
const message = document.getElementById("loginMessage");

function updateDots() {
  dots.forEach((dot, i) => dot.classList.toggle("filled", i < pin.length));
}

function submitPin() {
  if (pin.length === 4) {
    message.style.color = "#159447";
    message.textContent = "PIN hợp lệ — đang mở phiên làm việc...";
    setTimeout(() => {
      message.textContent = "";
      pin = "";
      updateDots();
    }, 1200);
  }
}

document.querySelectorAll("[data-key]").forEach(btn => {
  btn.addEventListener("click", () => {
    if (pin.length < 4) {
      pin += btn.dataset.key;
      updateDots();
      message.textContent = "";
      if (pin.length === 4) submitPin();
    }
  });
});

document.querySelector('[data-action="back"]').addEventListener("click", () => {
  pin = pin.slice(0, -1);
  updateDots();
  message.textContent = "";
});

document.querySelector('[data-action="reset"]').addEventListener("click", () => {
  pin = "";
  updateDots();
  message.textContent = "";
});

document.querySelectorAll(".role").forEach(role => {
  role.addEventListener("click", () => {
    document.querySelectorAll(".role").forEach(r => r.classList.remove("active"));
    role.classList.add("active");
    currentUser.textContent = `${role.dataset.name} (${role.dataset.role})`;
    pin = "";
    updateDots();
    message.textContent = "";
  });
});

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const pinMode = tab.dataset.tab === "pin";
    document.getElementById("pinView").classList.toggle("hidden", !pinMode);
    document.getElementById("accountView").classList.toggle("hidden", pinMode);
    message.textContent = "";
  });
});

document.getElementById("accountLogin").addEventListener("click", () => {
  message.style.color = "#d83b3b";
  message.textContent = "Đây là giao diện mẫu — kết nối API đăng nhập tại đây.";
});

document.addEventListener("keydown", e => {
  if (/^\d$/.test(e.key)) {
    const button = document.querySelector(`[data-key="${e.key}"]`);
    button?.click();
  } else if (e.key === "Backspace") {
    document.querySelector('[data-action="back"]').click();
  } else if (e.key === "Escape") {
    document.querySelector('[data-action="reset"]').click();
  }
});

document.getElementById("minBtn").onclick = () => window.electronAPI.minimize();
document.getElementById("maxBtn").onclick = () => window.electronAPI.toggleMaximize();
document.getElementById("closeBtn").onclick = () => window.electronAPI.close();