# NinoPOS Login - Windows EXE

Giao diện đăng nhập NinoPOS dạng Electron, thiết kế theo mockup đã yêu cầu.

## Chạy thử

Cài Node.js LTS, sau đó mở CMD/PowerShell tại thư mục dự án:

```bash
npm install
npm start
```

## Đóng gói thành file cài đặt EXE

```bash
npm run dist
```

File cài đặt sẽ nằm trong:

`dist/NinoPOS-Setup-1.0.0.exe`

## Cấu trúc

- `main.js`: Electron main process + cửa sổ không viền.
- `preload.js`: cầu nối an toàn giữa UI và Electron.
- `index.html`: giao diện.
- `styles.css`: toàn bộ style.
- `renderer.js`: xử lý PIN, chọn vai trò, tab tài khoản.
- `assets/ninopos-logo.png`: logo NinoPOS.

## Tích hợp backend

Phần xác thực hiện đang là UI mẫu. Có thể thay hàm `submitPin()` và sự kiện `accountLogin` bằng API thật của NinoPOS.

Ví dụ:
`POST /api/auth/login`

Sau khi xác thực thành công có thể chuyển sang màn hình bán hàng chính.