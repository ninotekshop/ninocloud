; Script Inno Setup cho phan mem NinoPOS
; Huong dan: Cai dat Inno Setup (https://jrsoftware.org/isdl.php), mo file .iss nay va nhan Compile (F9).

#define MyAppName "NinoPOS"
#define MyAppVersion "2.4.0"
#define MyAppPublisher "NINOTEK Technology & Solution"
#define MyAppURL "https://ninotek.vn"
#define MyAppExeName "NinoPOS.exe"

[Setup]
; Thong tin co ban cua ung dung
AppId={{D89B5B24-7F8A-421D-89F1-3F63B9B49A02}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppPublisher}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
; Thu muc chua file setup.exe xuat ra
OutputDir=Output
OutputBaseFilename=NinoPOS_Setup_v{#MyAppVersion}
SetupIconFile=SourceFilespp_icon.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "quicklaunchicon"; Description: "{cm:CreateQuickLaunchIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked; OnlyBelowVersion: 6.1; Check: not IsAdminInstallMode

[Files]
; Copy file thuc thi chinh va cac thu vien phu thuoc tu thu muc SourceFiles
Source: "SourceFiles\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "SourceFiles\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; Chu y: Khong de Source trung lap de tranh loi compile

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
