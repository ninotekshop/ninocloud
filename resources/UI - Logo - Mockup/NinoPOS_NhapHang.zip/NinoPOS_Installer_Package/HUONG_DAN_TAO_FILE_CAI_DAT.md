# HƯỚNG DẪN TẠO BỘ CÀI ĐẶT .EXE CHO NINOPOS BẰNG INNO SETUP

Bộ công cụ tiêu chuẩn và phổ biến nhất trên Windows hiện nay là **Inno Setup** (miễn phí, gọn nhẹ, chuyên nghiệp).

---

### Bước 1: Chuẩn bị file ứng dụng (SourceFiles)
1. Build ứng dụng của bạn ra file thực thi và các file phụ thuộc (DLLs, assets, runtime...).
2. Chép toàn bộ thư mục output build (bao gồm `NinoPOS.exe`, file cấu hình, database SQLite nếu có, icon `app_icon.ico`) vào thư mục `SourceFiles/`.

---

### Bước 2: Tải và cài đặt Inno Setup
* Tải bản mới nhất tại: https://jrsoftware.org/isdl.php
* Cài đặt Inno Setup Compiler lên máy Windows.

---

### Bước 3: Đóng gói bộ cài
1. Nhấp đúp chuột vào file `NinoPOS_Setup_Script.iss`.
2. Trình biên dịch **Inno Setup Compiler** sẽ mở ra.
3. Nhấn phím tắt **`F9`** (hoặc chọn menu `Build -> Compile`).
4. File cài đặt hoàn chỉnh `NinoPOS_Setup_v2.4.0.exe` sẽ được tạo trong thư mục `Output/`.

---

### Lưu ý cấu hình bổ sung trong file .iss:
- **Tự động chạy quyền Admin:** Nếu phần mềm lưu dữ liệu vào `C:\Program Files` hoặc can thiệp dịch vụ in ấn / cổng COM máy in bill, đổi `PrivilegesRequired=lowest` thành `PrivilegesRequired=admin`.
- **Thư viện .NET Framework / VC++ Redistributable:** Nếu ứng dụng dùng C#/WPF, bạn có thể thêm script kiểm tra và cài tự động .NET Desktop Runtime trong phần `[Code]`.
